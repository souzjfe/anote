console.info("chrome-ext template-preact-ts content script");
